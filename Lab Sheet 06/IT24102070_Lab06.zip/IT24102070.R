setwd("D:\\Preschool videos\\IT24102070")
#Exercise 
#Part 1
#Binomial Distribution
#x~Binomial(n=50,p=0.85)
pbinom(46,50,0.85,lower.tail=FALSE)

#Part 2
#Poisson Distribution   
dpois(15,12)
