 setwd("D:\\Preschool videos\\New folder (2)")
 #1
 #Arrive uniformely between 8.00 and 8.40 : ask(8.10 to 8.25)
 #P(P(10 < X < 25)
 punif(25,min=0,max=40)- punif(10,min=0,max=40)

 
 #2
pexp(2, rate=1/3, lower.tail=TRUE)


#3
# (i)
pnorm(130, mean=100, sd=15, lower.tail=FALSE)



#(ii)
qnorm(0.95, mean=100, sd=15, lower.tail=TRUE)

